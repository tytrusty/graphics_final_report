#include <iostream>
#include "fluid.h"
#include "heat.h"

Fluid_Sim::Fluid_Sim (int N, float viscosity, float diffusion, float time_step)
   : N_(N), diffusion_(diffusion), time_step_(time_step),
     enable_gravity_(false), enable_heat_(false),
     x(N, X_Velocity), x_old(N, X_Velocity), 
     y(N, Y_Velocity), y_old(N, Y_Velocity), 
     density(N, Density), density_old(N, Density),
     viscosity_grid(N), level_set_(N) 
{
    viscosity_grid.set_all(viscosity);
    level_set_.add_object(N/2, N/2);
}

void Fluid_Sim::simulation_step()
{
    // --------- Velocity Solver --------- //
    // Assuming external forces currently stored in x_old and y_old
    add_external_forces(x, x_old);
    add_external_forces(y, y_old);
     
    // Adding gravitational force
    if (enable_gravity_) {
        add_gravity(x);
    }
    swap(x, x_old); swap(y, y_old);

    // Viscous heat diffusion
    x.type_ = None;
    y.type_ = None;
    if (enable_heat_) {
        heat_boundary_.apply_heat(viscosity_grid);
    } 
    diffuse_viscosity(x, x_old, viscosity_grid);
    diffuse_viscosity(y, y_old, viscosity_grid);
    x.type_ = X_Velocity;
    y.type_ = Y_Velocity;

    // Enforce incompressibility
    project(x, y, x_old, y_old);
    swap(x, x_old); swap(y, y_old);
   
    // Self-Advection -- aka move velocity field along the velocity field
    advect(x, x_old, x_old, y_old);
    advect(y, y_old, x_old, y_old);

    // Enforce incompressibility, again
    project(x, y, x_old, y_old);

    // --------- Density Solver --------- //
    add_external_forces(density, density_old);
    swap(density, density_old);
    diffuse(density, density_old, diffusion_);
    swap(density, density_old);
    advect(density, density_old, x, y);

    // -- Level Set Advection -- // 
    swap(level_set_.dist_grid, level_set_.dist_grid_old);
    advect(level_set_.dist_grid, level_set_.dist_grid_old, x, y);

    density_old.reset();
    level_set_.dist_grid_old.reset();
    x_old.reset();
    y_old.reset();
}

void Fluid_Sim::reset() 
{
    x.reset();
    x_old.reset();
    y.reset();
    y_old.reset();
    density.reset();
    density_old.reset();
    level_set_.reset();
}

void Fluid_Sim::resize(int N) 
{
    N_ = N;
    x.resize(N);
    x_old.resize(N);
    y.resize(N);
    y_old.resize(N);
    density.resize(N);
    density_old.resize(N);
}

void Fluid_Sim::add_external_forces(Fluid_Grid<float>& target,
        Fluid_Grid<float>& source)
{
    for (int i = 0; i < (N_+2)*(N_+2); ++i) {
        //TODO ---- DONT ADD IF NOT LIQUID DUMMY
        target.array_[i] += source.array_[i] * time_step_;  
    }   
}
 
void Fluid_Sim::add_gravity(Fluid_Grid<float>& y) {
	float amount = -9.8f * time_step_;
    // ALSO ADD GRAVITY ON CELLS DIRECTLY ABOVE
    // AKA IF CELL HAS A DUDE BELOW IT THAT IS IN LIQUID, THEN LET GRAVITY DO SHIT
    for (int i = 1; i <= N_; ++i) {
        for (int j = 1; j <= N_; ++j) {
            if (level_set_.is_liquid(i, j) || level_set_.is_liquid(i-1,j)) {
                y(i, j) += amount;
            }
        }
    }
}


void Fluid_Sim::adjust_bounds(Fluid_Grid<float>& grid)
{
    // Handling edges
    for (int i = 0; i <= N_ + 1; ++i) {
        // For every column in the simulation, the flow to the top and bottom
        // rows should be 0 for the vertical velocity
        grid(0,    i) = (grid.type_ == X_Velocity || 1) ?  -grid(1, i)  : grid(1,  i); 
        grid(N_+1, i) = (grid.type_ == X_Velocity || 1) ?  -grid(N_, i) : grid(N_, i); 

        // For every row in the simulation, the flow to the left and right edges
        // should have a 0 X flow
        grid(i,    0) = (grid.type_ == Y_Velocity || 1) ?  -grid(i, 1)  : grid(i,  1); 
        grid(i, N_+1) = (grid.type_ == Y_Velocity || 1) ?  -grid(i, N_) : grid(i, N_); 
    }


    // Handling corners -- average out the two nearest
    grid(0,       0) = 0.5 * (grid(1,     0) + grid(0,     1));
    grid(0,    N_+1) = 0.5 * (grid(1,  N_+1) + grid(0,    N_));
    grid(N_+1,    0) = 0.5 * (grid(N_,    0) + grid(N_+1,  1));
    grid(N_+1, N_+1) = 0.5 * (grid(N_, N_+1) + grid(N_+1, N_));
}
 
void Fluid_Sim::gauss_seidel(Fluid_Grid<float>& grid, 
        Fluid_Grid<float>& grid_prev, float a, float c)
{
    // _Pragma("omp parallel for")
    for (int step = 0; step < solver_steps; ++step) {
        for (int i = 1; i <= N_; ++i) {
            for (int j = 1; j <= N_; ++j) {
                grid(i, j) = (grid_prev(i,j) + a * (grid(i-1,j) + grid(i+1,j) 
                        + grid(i,j-1) + grid(i,j+1))) / c;
            }
        }
        // Adjust the boundaries of the array after changing values
        adjust_bounds(grid);
    }
}
 
void Fluid_Sim::gauss_seidel_viscosity(Fluid_Grid<float>& grid, 
        Fluid_Grid<float>& grid_prev, Fluid_Grid<float>& viscosity)
{
    // _Pragma("omp parallel for")
    for (int step = 0; step < solver_steps; ++step) {
        for (int i = 1; i <= N_; ++i) {
            for (int j = 1; j <= N_; ++j) {
                float a = time_step_ * viscosity(i, j) * N_ * N_;
                float c = 1 + 4 * a; 
                grid(i, j) = (grid_prev(i,j) + a * (grid(i-1,j) + grid(i+1,j) 
                        + grid(i,j-1) + grid(i,j+1))) / c;
            }
        }
        // Adjust the boundaries of the array after changing values
        adjust_bounds(grid);
    }
}

void Fluid_Sim::diffuse_viscosity(Fluid_Grid<float>& grid, Fluid_Grid<float>& grid_prev,
        Fluid_Grid<float>& viscosity)
{
    gauss_seidel_viscosity(grid, grid_prev, viscosity);
}

void Fluid_Sim::diffuse(Fluid_Grid<float>& grid, Fluid_Grid<float>& grid_prev,
        float rate)
{
    float a = time_step_ * rate * N_ * N_;
    float c = 1 + 4*a;
    gauss_seidel (grid, grid_prev, a, c);
}

static float vdiv = 0.0f;
static float y_volume = 0.0f;
static float volume_error = 0.0f;

void Fluid_Sim::compute_volume_error() {
	float curr_volume = level_set_.volume_;
    float prev_volume = level_set_.volume_prev_;
	if( ! prev_volume || ! curr_volume ) {
		vdiv = 0.0;
		return;
	}
	volume_error = prev_volume-curr_volume;
	
	float x = (curr_volume - prev_volume)/prev_volume;
	y_volume += time_step_*x;
	
	float kp = 2.3 / (25.0 * time_step_);
	float ki = kp*kp/16.0;
	vdiv = -(kp * x + ki * y_volume) / (x + 1.0);
    std::cout << "vol error " << volume_error << std::endl;
}

void Fluid_Sim::project(Fluid_Grid<float>& x, Fluid_Grid<float>& y, 
        Fluid_Grid<float>& p, Fluid_Grid<float>& div)
{
    // _Pragma("omp parallel for")
    // Get divergence of velocity field
    for (int i = 1; i <= N_; ++i) {
        for (int j = 1; j <= N_; ++j) {
            div(i,j) = (x(i+1,j) - x(i-1,j) + y(i, j+1) - y(i, j -1)) * -0.5f / N_;
            p(i,j) = 0;
        }
    }
    adjust_bounds(div);
    adjust_bounds(p);
    // Solving poisson equation of the form
    // Laplacian(pressure) = divergence of velocity field
    // This is equivalent to a linear system of the form Ax = b where
    // x is the pressure. Gauss seidel numerical solver will be used
    // to solve for pressure. 
    gauss_seidel (p, div, 1, 4);
    
    // _Pragma("omp parallel for")
    // Subtract pressure to get divergent free velocity field
    for (int i = 1; i <= N_; ++i) {
        for (int j = 1; j <= N_; ++j) {
            x(i,j) -=  0.5f * N_ * (p(i+1,j) - p(i-1,j));
            y(i,j) -=  0.5f * N_ * (p(i,j+1) - p(i,j-1));
        }
    }
    adjust_bounds(x);
    adjust_bounds(y);
}
 
void Fluid_Sim::advect(Fluid_Grid<float>& grid, Fluid_Grid<float>& grid_prev,
        Fluid_Grid<float>& x_velocity, Fluid_Grid<float>& y_velocity)
{
    int x_lo, x_hi, y_lo, y_hi;
    float x, y, x_w, y_w;

    // How much in time to step back
    float dt0 = time_step_ * N_;

    for (int i = 1; i <= N_; ++i) {
        for (int j = 1; j <= N_; ++j) {
            // Backtrace i according to the velocity field's x value
            x = i - dt0 * x_velocity(i,j);
            if (x < 0.5)           x = 0.5;
            else if (x > N_ + 0.5) x = N_ + 0.5;

            // Get lower and upper bound cells
            x_lo  = (int) x;
            x_hi = x_lo + 1;

            // Backtrace j according to velocity field's y value
            y = j - dt0 * y_velocity(i,j);
            if (y < 0.5)           y = 0.5;
            else if (y > N_ + 0.5) y = N_ + 0.5; 

            // Get bounds on j cells
            y_lo  = (int) y;
            y_hi = y_lo + 1;
            
            // Perform advection by linearly interpolating from the
            // values at the backtraced cells
            x_w = x - x_lo; // x parametric weight
            y_w = y - y_lo; // y parametric weight
            
            // Bilinearly interpolating the new scalar value
            grid(i,j) = 
                (1 - x_w) * lerp(grid_prev(x_lo, y_lo), grid_prev(x_lo, y_hi), y_w)
                    + x_w * lerp(grid_prev(x_hi, y_lo), grid_prev(x_hi, y_hi), y_w);
        }
    }
    // Adjust the boundaries of the array after changing values
    adjust_bounds(grid);
} 
